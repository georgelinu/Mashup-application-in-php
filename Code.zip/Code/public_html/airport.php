
<?php
$countrySelected = array();
$airports_in_sweden=array();
$storeAirportsName=array();
if (isset($_POST['countrySelected'])) {
    $countrySelected=$_POST['countrySelected'];
}
$mysqli = new mysqli("localhost", "id15552110_mashuproot", "W-+?M=Fja/VW0kGa", "id15552110_mashup");
$queryString = http_build_query([
  'access_key' => '**************************'
]);
$ch = curl_init(sprintf('%s?%s', 'http://api.aviationstack.com/v1/airports', $queryString));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$json = curl_exec($ch);
curl_close($ch);
$api_result = json_decode($json, true);
$airports=array();
$airports_in_sweden=array();
$pass_data=array();
$airport_arr=array();
    for($i = 0; $i < count($api_result['data']); $i++){
        $airport['airport_name']=$api_result['data'][$i]['airport_name'];
        $airport['country_name']=$api_result['data'][$i]['country_name'];
        $airport['lat']=$api_result['data'][$i]['latitude'];
        $airport['long']=$api_result['data'][$i]['longitude'];
        if($api_result['data'][$i]['country_name']==$countrySelected){
          array_push($airports_in_sweden,$airport);
        }
            $cN = $airport['country_name']; //from input
            $result = mysqli_query($mysqli,"SELECT * FROM country WHERE countryName='" . $cN . "'");
            if (mysqli_num_rows($result) == 1)
            {
            continue;
            }
            else {
            $sql = "INSERT INTO country (countryName) VALUES ('" . $airport['country_name'] . "')";
            $insert =  $mysqli->query($sql);
            }
    }
    echo json_encode($airports_in_sweden);
?>