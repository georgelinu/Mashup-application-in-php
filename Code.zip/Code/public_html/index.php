<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MashUp System</title>
<link rel="icon" href="images/lg-fav.png" type="image/png" sizes="31x31">
<link rel="stylesheet" type="text/css" href="css/styles.css" media="screen"/>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster">
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
</head>
<body>
<div >
<!-- Google Map will be displayed here -->
    <div id="googleMap" style="width:100%;height:693px;"></div>
    <div class="wrap">
        <div class="search">
            <input id="countryTyped" type="text" class="searchTerm" placeholder="Enter a country name...">
            <button type="submit" class="searchButton" onclick="myMap()">
                <i class='fas fa-search'></i>
            </button>
            <div class="result" style="background-color:powderblue;">
                <!-- Search result will be displayed here -->
            </div>
        </div>
    </div>
    <!-- Weather code -->
        <div class="report-container" style="margin-top:-35%;" id="weatherElement">
            <h2> Weather Forecast: </h2>
            <h3 id="locationNameId"> </h3>
            <div class="weather-forecast">
                <img id="weatherImageId" src="http://openweathermap.org/img/w/.png" class="weather-icon"/> 
                <span id="weatherTempMaxId"> </span>&deg;C
                <span id="weatherTempMinId" class="min-temperature">&deg;C</span>
            </div>
                <div><li id="weatherDescriptionId"> </li></div>
            <div class="time">
                <div><li >Humidity: <span id="weatherHumidityId"> </span> %</li></div>
                <div><li >Wind: <span id="weatherWindId"></span> km/h</li></div>
            </div>
        </div>
        <!-- Footer -->
    <div class="bottomcontainer sticky">
        <div>
            <p class="w3-lobster w3-xxxsmaller footertext">Designed by: LNU</p>
        </div>
    </div>
</div>
<script>
function myMap() {
    document.getElementById('weatherElement').style.display = "none"; 
    var airports;
    var locations;
    var countrySelected;
    if(document.getElementById("countryTyped").value){
        countrySelected = document.getElementById("countryTyped").value;
    }
    else{
         countrySelected ='Russia';
    }
    console.log("countrySelected",countrySelected);
    jQuery.ajax({
        url: 'airport.php',
        method: 'POST',
        data: {"countrySelected":countrySelected},
            error:function(data)
            {
                alert("failed");
                console.log(data);
            },
            success: function(response) 
            {
                console.log(response);
                var airports=JSON.parse(response);
                console.log(airports);
                var airport_array=[];
                for(i = 0; i < airports.length; i++){
                    console.log("i=",i);
                    console.log("airports[i]",airports[i]);
                    data=[airports[i].airport_name,Number(airports[i].lat),Number(airports[i].long)];
                    airport_array.push(data);     
                }
                console.log(airport_array);
    locations=airport_array;
    console.log(locations);
    var map = new google.maps.Map(document.getElementById('googleMap'), {
                  zoom: 3,
                  center: new google.maps.LatLng(22.28130517933514, 75.12195708210523),
                  mapTypeId: google.maps.MapTypeId.ROADMAP
                });
                var infowindow = new google.maps.InfoWindow();
                var marker, i;
                console.log("locations",locations)
                for (i = 0; i < locations.length; i++) {  
                    console.log("locations[i][1], locations[i][2]",locations[i][1], locations[i][2]); 
                  marker = new google.maps.Marker({
                    position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                    map: map
                  });
                  google.maps.event.addListener(marker, 'click', (function(marker, i) {
                    return function() {
                        map.setZoom(4);
                        map.setCenter(marker.getPosition());
                      infowindow.setContent(locations[i][0]);
                      infowindow.open(map, marker);
                        var lati = locations[i][1];
                        var long = locations[i][2];
                        console.log("in index lati: ",lati,"   in index long:  ",long);
                        jQuery.ajax({
                                url: 'weather.php',
                                method: 'POST',
                                 data: { "latloc": lati, "lonloc": long },
                                    error:function(data)
                                    {
                                        alert("failed");
                                        console.log(data);
                                    },
                                    success: function(data) 
                                    {
                                        document.getElementById('weatherElement').style.display = "block"; 
                                        console.log(data);
                                        var weatherData = JSON.parse(data);
                                        console.log(weatherData);
                                        console.log(weatherData.name);
                                        document.getElementById("locationNameId").innerHTML=weatherData.name;
                                        document.getElementById("weatherTempMaxId").innerHTML=weatherData.main.temp_max;
                                        document.getElementById("weatherTempMinId").innerHTML=weatherData.main.temp_min;
                                        document.getElementById("weatherHumidityId").innerHTML=weatherData.main.humidity;
                                        document.getElementById("weatherWindId").innerHTML=weatherData.wind.speed;
                                        document.getElementById("weatherDescriptionId").innerHTML=weatherData.weather[0].description;
                                        document.getElementById("weatherImageId").src = "http://openweathermap.org/img/w/"+weatherData.weather[0].icon+".png"; 
                                    }
                            }); 
                    }
                  })(marker, i));
                }
            }
  });
}
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=**************************&callback=myMap"></script>
</body>
</html>